﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CS408_Project_Server
{
    public partial class Form1 : Form
    {

        Socket serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        List<Socket> clientSockets = new List<Socket>();    //To store sockets
        List<string> clientNames = new List<string>();      //To store name list

        bool terminating = false;
        bool listening = false;

        private ReaderWriterLockSlim databaseLock = new ReaderWriterLockSlim();

        //private static Mutex mut = new Mutex();

        string failed = "0"; 
        string successful = "1";
        string path2;        //path2 is the path for database txt file

        StreamWriter sw;    //StreamWriter is used for writing on file.

        const int BUFFER_SIZE = 2048;

        private static string fileName = "";
        private static string shortFileName = "";
        FolderBrowserDialog fbd = new FolderBrowserDialog();

        public Form1()
        {
            Control.CheckForIllegalCrossThreadCalls = false;
            this.FormClosing += new FormClosingEventHandler(Form1_FormClosing);
            InitializeComponent();
        }

        private void button_listen_Click(object sender, EventArgs e)
        {
            int serverPort;

            if (Int32.TryParse(textBox_port.Text, out serverPort))      //parses the server port, and assigns it.
            {
                IPEndPoint endPoint = new IPEndPoint(IPAddress.Any, serverPort);
                serverSocket.Bind(endPoint);
                serverSocket.Listen(100);   //binds server socket to endpoint. Starts listening.

                listening = true;
                button_listen.Enabled = false;

                Thread acceptThread = new Thread(Accept);   //this thread accepts clients by listening.
                acceptThread.Start();   //start the thread
                logs.AppendText("Started listening on port: " + serverPort + "\n");
                sw = new StreamWriter(@path2, true);    //to reach the database file.
            }
            else    //if port is incorrect.
            {
                logs.AppendText("Invalid port number.\n");
            }
        }
        private void Accept()   //accepting the client to server.
        {
            while (listening)   
            {
                try
                {
                    Socket newClient = serverSocket.Accept();

                    Thread checkThread = new Thread(() => checkUsername(newClient));  //checks if username is unique.
                    checkThread.Start();                 
                }
                catch
                {
                    if (terminating)
                    {
                        listening = false;
                    }
                    else
                    {
                        logs.AppendText("The socket stopped working.\n");
                    }
                }
            }
        }

        private bool isUnique(List<string> list, string name)   //given a name and a list, returns true if the name is not in the list.
        {
            foreach (string n in list)
            {
                if (n.Equals(name))
                    return false;
            }
            return true;
        }

        private void checkUsername(Socket thisClient)       //To check the username.
        {
            try
            {
                Byte[] buffer = new Byte[100];
                thisClient.Receive(buffer);

                string name = Encoding.UTF8.GetString(buffer);   //getting the name of the client.
                name = name.Substring(0, name.IndexOf("\0"));

                if (isUnique(clientNames, name))    //if the name is not already in the server.
                {
                    Byte[] respbuffer = Encoding.UTF8.GetBytes(successful);  //give success response buffer.
                    thisClient.Send(respbuffer);    //send to client.
                    clientSockets.Add(thisClient);  //add the client in client sockets.
                    clientNames.Add(name);          //add the name of the client in the name list.
                    logs.AppendText(name + " is connected.\n");
                    Thread receiveThread = new Thread(() => Receive(thisClient, name)); //start thread for this client.
                    receiveThread.Start();
                }
                else    //if the name is already in the server.
                {
                    Byte[] respbuffer = Encoding.UTF8.GetBytes(failed);      //the response buffer.
                    thisClient.Send(respbuffer);    //send the response buffer.
                    thisClient.Close();     //close the client.
                    logs.AppendText("A client tried to connect with a duplicate username: " + name + "\n");     //give error.
                }
            }
            catch
            {
                thisClient.Close();     //if there is a problem, close the client.
            }
        }

        // Thread function for receiving the file data.
        private void Receive(Socket thisClient, string name)    
        {
            bool connected = true;

            while (connected && !terminating)
            {
                /*
                 * The server gets a request code informing which function will be used by the client.
                 * Then, appropriate functions are used.
                 * The following is the request codes used by clients stating
                 * which code is used for which functionality:
                 * 
                 *        Functionality                      Response Codes
                 *   ------------------------               -----------------
                 *   Send file to server                            1
                 *   Download a public file from server             2
                 *   Create a copy of a file                        3
                 *   Delete a file                                  4
                 *   Get the list of private files                  7
                 *   Make desired file public                       8
                 *   Get the list of public files                   9
                 *   Download a private file from server           10
                 *  
                 *****************************************************************************   
                 */

                try
                {
                    // get the functionality code
                    byte[] requestByte = new byte[4];
                    int requestSize = thisClient.Receive(requestByte);
                    int requestCode = BitConverter.ToInt32(requestByte, 0);

                    // get the list of private files
                    if (requestCode == 7)
                    {
                        sendPrivateFileList(name, thisClient, ref connected);
                    }

                    // send a desired public file from server to client
                    else if (requestCode == 2)
                    {
                        publicSendData(thisClient, name, ref connected);
                    }

                    // create a copy of a file
                    else if (requestCode == 3)
                    {
                        createCopy(thisClient, name, ref connected);
                    }

                    // delete a file 
                    else if (requestCode == 4)
                    {
                        DeleteFile(thisClient, name, ref connected);
                    }

                    // make a file public
                    else if (requestCode == 8) 
                    {
                        MakePublic(name, thisClient, ref connected);
                    }

                    // send the list of public files
                    else if (requestCode == 9)
                    {
                        sendPublicFileList(thisClient, name, ref connected);
                    }

                    // send a private file from server to client
                    else if (requestCode == 10)
                    {
                        sendPrivateData(thisClient, name, ref connected);
                    }

                    // get a file from client
                    else if (requestCode == 1)
                    {
                        string fileName = "";
                        int totalBytes = downloadFile(thisClient, name, ref connected, ref fileName);

                        if (totalBytes != -1)
                        {
                            try
                            {
                                databaseLock.EnterWriteLock();
                                DateTime now = DateTime.Now;
                                using (sw = new StreamWriter(@path2, true))
                                {
                                    sw.WriteLine(name + "\t" + fileName + "\t" + now.ToString() + "\t" + totalBytes + "\tprivate");
                                    sw.Flush();
                                    sw.Close();
                                }
                                logs.AppendText("Database is successfully updated.\n");
                            }
                            catch
                            {
                                logs.AppendText("An error has occurred while updating the database: " + name + " tried to send " + fileName + ".\n");
                                // SEND RESPONSE CODE --> ERROR
                                byte[] fail = { 19 };
                                thisClient.Send(fail);
                            }
                            finally
                            {
                                databaseLock.ExitWriteLock();
                            }                            
                        }
                        else
                        {
                            // SEND RESPONSE CODE --> ERROR
                            byte[] fail = { 19 };
                            thisClient.Send(fail);
                        }
                    }
                }
                
                catch (SocketException e)
                {
                    if (!terminating)   // if user is disconnected, removes its name and socket from lists.
                    {
                        logs.AppendText(name + " has disconnected.\n");
                    }
                    //mut.WaitOne();
                    thisClient.Close();
                    clientSockets.Remove(thisClient);
                    clientNames.Remove(name);
                    connected = false;
                }
            }
        }

        private int downloadFile(Socket client, string userName, ref bool connected, ref string fileName)
        {
            /* Returns the total bytes the server received from the client
             * If an error occurs, it returns -1.
             * 
             * 1- Before starting, inform client that the server started to wait for file name and size of the file
             *  
             * 2- Then, get the name of the file and size of the file from the client.
             * 
             * 3- Name of the file is updated in updateFileNameBeforeInsert function appropriately.
             * For example, if the user name is "user1" and file name is "data", file name is
             * converted to user1_data_X.txt. X is found in updateFileNameBeforeInsert, which represents 
             * the number of files whose name is same as current file name.     
             *  
             * 4- The size of the file is used to construct the while loop which is created to get 
             * chunks of data whose max size is BUFFER_SIZE = 2048. As the server gets the data, size of
             * the file is updated accordingly.
             * 
             * 5- Received data is written to a text file by using BinaryWriter class.
             * 
             ***********************************************************************************************
            */

            try
            {
                // 1
                byte[] start = { 105 };
                client.Send(start);

                // 2
                byte[] sizeAndFileName = new byte[BUFFER_SIZE];
                int dataLen = client.Receive(sizeAndFileName, sizeAndFileName.Length, 0);
                if (dataLen == 0) {
                    throw new ObjectDisposedException(userName);
                }        

                int fileNameLen = BitConverter.ToInt32(sizeAndFileName, 0);
                fileName = Encoding.UTF8.GetString(sizeAndFileName, 4, fileNameLen);
                string oldFileName = fileName;
                int bytesLeftToReceive = BitConverter.ToInt32(sizeAndFileName, 4 + fileNameLen); // get the size
                int totalBytes = bytesLeftToReceive;

                // update the file name
                int count = updateFileNameBeforeInsert(userName, ref fileName, path2);
                if (count == -1) // an error occurred while reading from database
                {
                    return -1;
                }
                byte[] clientData = new byte[BUFFER_SIZE];

                // create the file in selected directory
                BinaryWriter bWrite = new BinaryWriter(File.Open(@fbd.SelectedPath + "\\" + fileName, FileMode.Append));

                // get data as long as client sends data
                while (bytesLeftToReceive > 0)
                {
                    int bytesRead = client.Receive(clientData, BUFFER_SIZE, 0);
                    if (bytesRead == 0)
                        throw new ObjectDisposedException(userName);
                    bWrite.Write(clientData, 0, bytesRead); // 5
                    int bytesToCopy = Math.Min(bytesRead, bytesLeftToReceive); // can be commented out
                    bytesLeftToReceive -= bytesToCopy;
                }

                bWrite.Close();
                logs.AppendText(userName + " sent " + oldFileName + "\n");
                logs.AppendText("File received successfully.\n");

                // SEND RESPONSE CODE
                byte[] success = { 18 };
                client.Send(success);

                return totalBytes;
            }

            catch (SocketException e)
            {
                if (!terminating)   // if user is disconnected, removes its name and socket from lists.
                {
                    logs.AppendText(userName + " has disconnected.\n");
                }
                client.Close();
                clientSockets.Remove(client);
                clientNames.Remove(userName);
                connected = false;
                // NO NEED TO SEND RESPONSE CODE, CLIENT HAS ALREADY DISCONNECTED
                return -1;
            }

        
            catch (ObjectDisposedException e)
            {
                logs.AppendText("A data chunk couldn't be received while downloading file from " + userName + ".\n");
                return -1;
            }

            catch (IOException e)
            {
                logs.AppendText("An I/O error while downloading file from " + userName + ".\n");
                return -1;
            }

            catch (Exception e)
            {
                logs.AppendText("An error occurred while downloading file from " + userName + ".\n");
                return -1;
            }
        }

        private void Form1_FormClosing(object sender, System.ComponentModel.CancelEventArgs e)  //classical form closing
        {
            listening = false;
            terminating = true;
            Environment.Exit(0);
        }

        private void button_browse_Click(object sender, EventArgs e)
        {
            fbd.RootFolder = Environment.SpecialFolder.MyComputer;  //Making the rootfolder for folder searching My Computer.
            fbd.Description = "Select Folder";
            fbd.ShowNewFolderButton = false;

            if (fbd.ShowDialog() == DialogResult.OK)    //If server side chose the folder.
            {
                textBox_browse.Text = fbd.SelectedPath;     //Show the path on textBox.
                textBox_port.Enabled = true;
                button_listen.Enabled = true;
                path2 = textBox_browse.Text + "\\database.txt";    //Merge folder path and x.txt.
            }
        }

        private int updateFileNameBeforeInsert(string userName, ref string fileName, string path)   
        {
            databaseLock.EnterReadLock(); // NEWLY ADDED
            sw.Close();     //closes the stream in order to read the file properly.
            fileName = fileName.Substring(0, fileName.Length - 4);      //removing the .txt part
            int count = 1;
            
            try {
                using (FileStream fs = new FileStream(@path2, FileMode.Open, FileAccess.Read, FileShare.Read))  //opening file to read
                {
                    StreamReader reader = new StreamReader(fs);
                    string line;
                    while ((line = reader.ReadLine()) != null)      //while we can read a line
                    {
                        string[] line_arr = line.Split('\t');   //This part hecks the line. If username and filename are same, increases the count by 1.
                        string tempFileName = line_arr[1];
                        int firstIndex = tempFileName.IndexOf('_');
                        int lastIndex = tempFileName.LastIndexOf('_');
                        string filename_count = line_arr[1];
                        tempFileName = tempFileName.Substring(firstIndex + 1, lastIndex - firstIndex - 1);     
                        if (userName == line_arr[0] && fileName == tempFileName)
                        {
                            count = int.Parse(filename_count.Substring(filename_count.LastIndexOf('_') + 1,
                                                                 filename_count.LastIndexOf('.') - filename_count.LastIndexOf('_') - 1)) + 1;
                        }
                    }
                    
                    fileName = userName + "_" + fileName + "_" + count.ToString() + ".txt";
                    reader.Close();     
                }
            }
            catch
            {
                logs.AppendText("There is a problem related to reading data.\n");
                count = -1; // NEWLY ADDED
            }
            finally // NEWLY ADDED
            {
                databaseLock.ExitReadLock();
            }

            return count;
        }

        private void createCopy(Socket thisClient, string userName, ref bool connected)
        {
            /* It copies the file according to given parameters.
             *
             * 1- It checks if the file to be copied exists using checkFileExists function.
             *  a. If it doesn't exist, inform the client by sending a response code.
             *  b. If it exists, get the status (private/public) of the file and count info wrt other files.
             * 
             * 2- Then, update the file name and create a copy of the file w/ new name.
             * 
             * 3- Lastly, update the database w/ obtained infos (status, count, new file name).
             * 
             ************************************************************************************************
             */

            string fileToBeCopied = "";

            try
            {
                byte[] fileCopyByte = new byte[BUFFER_SIZE];
                thisClient.Receive(fileCopyByte);
                fileToBeCopied = Encoding.UTF8.GetString(fileCopyByte);
                fileToBeCopied = fileToBeCopied.Substring(0, fileToBeCopied.IndexOf('\0'));

                int count = 0;
                string status = "";
                bool error = false;
                bool exists = checkFileExists(userName, fileToBeCopied, ref count, path2, ref status, ref error);

                if (!exists && !error)
                {
                    byte[] response = { 20 };
                    thisClient.Send(response);
                    logs.AppendText(userName + " tried to copy a non-existing file: " + fileToBeCopied + "\n");
                }

                else if (error)
                {
                    byte[] response = { 2 };
                    thisClient.Send(response);
                    logs.AppendText("An error has occurred while " + userName + " trying to copy " + fileToBeCopied +  ".\n");
                }

                else
                {
                    // update the file name with new count
                    string fileNameNoCount = fileToBeCopied.Substring(0, fileToBeCopied.LastIndexOf('_'));
                    string newCopyFileName = userName + "_" + fileNameNoCount + "_" + (count + 1).ToString() + ".txt";
         
                    // create and copy the file to be copied w/ new name
                    File.Copy(Path.Combine(@fbd.SelectedPath, userName + "_" + fileToBeCopied + ".txt"),
                              Path.Combine(@fbd.SelectedPath, newCopyFileName));

                    logs.AppendText("The copy of the file " + fileToBeCopied + " is successfully created.\n");

                    // obtain the size of the file by reading the data of the file to be copied for database update
                    byte[] fileData = File.ReadAllBytes(Path.Combine(@fbd.SelectedPath, userName + "_" + fileToBeCopied + ".txt"));
                    byte[] fileSize = BitConverter.GetBytes(fileData.Length);
                    int totalBytes = BitConverter.ToInt32(fileSize, 0);

                    // update database 
                    try
                    {
                        databaseLock.EnterWriteLock(); // NEWLY ADDED
                        DateTime now = DateTime.Now;
                        using (sw = new StreamWriter(@path2, true))
                        {
                            sw.WriteLine(userName + "\t" + newCopyFileName + "\t" + now.ToString() + "\t" + totalBytes + "\t" + status);
                            sw.Flush();
                            sw.Close();
                        }
                        logs.AppendText("Database is successfully updated.\n");

                        // SEND RESPONSE CODE --> SUCCESSFUL COPY
                        byte[] response = { 1 };
                        thisClient.Send(response);
                    }

                    catch (SocketException e)
                    {
                        if (!terminating)   // if user is disconnected, removes its name and socket from lists.
                        {
                            logs.AppendText(userName + " has disconnected.\n");
                        }
                        thisClient.Close();
                        clientSockets.Remove(thisClient);
                        clientNames.Remove(userName);
                        connected = false;
                    }

                    catch
                    {
                        // SEND RESPONSE CODE --> UNSUCCESSFUL COPY
                        byte[] failure = { 2 };
                        thisClient.Send(failure);
                        logs.AppendText("An error during database update for copying file " + fileToBeCopied + " has occurred.\n");
                    }

                    finally
                    {
                        databaseLock.ExitWriteLock(); // NEWLY ADDED
                    }         
                }
            }

            catch (SocketException e)
            {
                if (!terminating)   // if user is disconnected, removes its name and socket from lists.
                {
                    logs.AppendText(userName + " has disconnected.\n");
                }
                thisClient.Close();
                clientSockets.Remove(thisClient);
                clientNames.Remove(userName);
                connected = false;      
            }

            catch (IOException copyError)
            {
                // SEND RESPONSE CODE --> UNSUCCESSFUL COPY
                byte[] response = { 2 };
                thisClient.Send(response);
                logs.AppendText("An error occurred during copying the file " + fileToBeCopied + "\n");
            }

            catch (Exception e)
            {
                // SEND RESPONSE CODE --> UNSUCCESSFUL COPY
                byte[] response = { 2 };
                thisClient.Send(response);
                logs.AppendText("An error occurred during copying the file " + fileToBeCopied + "\n");
            }
        }

        private bool checkFileExists(string userName, string fileName, ref int count, string path, ref string status, ref bool error)
        {
            bool result = false;
            try
            {
                databaseLock.EnterReadLock(); // NEWLY ADDED
                sw.Close();
                string fileNameTrimmed = fileName.Substring(0, fileName.LastIndexOf('_'));
                using (FileStream fs = new FileStream(@path2, FileMode.Open, FileAccess.Read, FileShare.Read))  //opening file to read
                {
                    StreamReader reader = new StreamReader(fs);
                    string line;
                    while ((line = reader.ReadLine()) != null)      //while we can read a line
                    {
                        string[] line_arr = line.Split('\t');   //This part hecks the line. If username and filename are same, increases the count by 1.
                        string tempFileName = line_arr[1];
                        string toCompare = tempFileName.Substring(tempFileName.IndexOf('_') + 1, tempFileName.IndexOf(".txt") - tempFileName.IndexOf('_') - 1);
                        string username_filename = tempFileName.Substring(0, tempFileName.LastIndexOf('_'));
                        if (username_filename.Equals(userName + '_' + fileNameTrimmed))
                        {
                            if (toCompare.Equals(fileName))
                            {
                                result = true;
                                status = line_arr[4];
                            }
                            count = int.Parse(tempFileName.Substring(tempFileName.LastIndexOf('_') + 1,
                                                                     tempFileName.LastIndexOf('.') - tempFileName.LastIndexOf('_') - 1));
                        }
                    }
                    reader.Close();
                }
            }
            
            catch
            {
                logs.AppendText("There is a problem related to reading data.\n");
                error = true;
            }

            finally // NEWLY ADDED
            {
                databaseLock.ExitReadLock();
            }

            return result;
        }
        private void DeleteFile(Socket thisClient, string name, ref bool connected)
        { // this function takes a file name and deletes it from the cloud


            string fileNameSent = "";
            try
            {
                byte[] delArray = new byte[BUFFER_SIZE];
                thisClient.Receive(delArray);
                fileNameSent = Encoding.UTF8.GetString(delArray);
                fileNameSent = fileNameSent.Substring(0, fileNameSent.IndexOf('\0'));

                string fileNameToDel = name + "_" + fileNameSent + ".txt";
                if (File.Exists(@fbd.SelectedPath + "\\" + fileNameToDel))
                { // if there is such file existing, delete it and send proper response code
                    File.Delete(@fbd.SelectedPath + "\\" + fileNameToDel);
                    byte[] delResponseArr = { 10 };
                    thisClient.Send(delResponseArr);
                    logs.AppendText(name + " deleted the file " + fileNameToDel + "\n");
                }
                else
                { // if there is no such file send proper response code back
                    byte[] delResponseArr = { 11 };
                    thisClient.Send(delResponseArr);
                    logs.AppendText(name + " tried to delete a non-existing file.\n");
                    return; // new
                }

                // database update
                // creates a empty temporary file and writes every line in database into it except deleted one
                try
                {
                    databaseLock.EnterWriteLock();
                    sw.Close();
                    var tempFile = Path.GetTempFileName();
                    var linesToKeep = File.ReadLines(path2).Where(l => !l.Contains(fileNameToDel));

                    File.WriteAllLines(tempFile, linesToKeep);

                    File.Delete(path2);
                    File.Move(tempFile, path2); // changes temporary file with original database
                                                // there database is updated correctly
                    logs.AppendText("Database is successfully updated.\n");
                }
                catch
                {
                    logs.AppendText("An error related to file operations has occurred while deleting " + fileNameSent + ".\n");
                    // send response code
                    byte[] code = { 2 };
                    thisClient.Send(code);
                }

                finally
                {
                    databaseLock.ExitWriteLock();
                }
            }
            
            catch (SocketException e)
            {
                if (!terminating)   // if user is disconnected, removes its name and socket from lists.
                {
                    logs.AppendText(name + " has disconnected.\n");
                }
                thisClient.Close();
                clientSockets.Remove(thisClient);
                clientNames.Remove(name);
                connected = false;
            }

            catch (Exception e)
            {
                logs.AppendText("An unknown error related has occurred while deleting " + fileNameSent + ".\n");
                // send response code
                byte[] code = { 2 };
                thisClient.Send(code);
            }
        }

        private void sendPrivateFileList(string userName, Socket client, ref bool connected)
        { // this function sends private files of a user
            try
            {
                databaseLock.EnterReadLock(); // NEWLY ADDED
                sw.Close();
                using (FileStream fs = new FileStream(@path2, FileMode.Open, FileAccess.Read, FileShare.Read))  //opening file to read
                {
                    StreamReader reader = new StreamReader(fs);
                    string result = "";
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        string[] line_arr = line.Split('\t');
                        string user = line_arr[0];
                        string fileName = line_arr[1];
                        fileName = fileName.Substring(fileName.IndexOf('_') + 1);
                        if (user == userName)
                        {
                            result += fileName + " " + line_arr[2] + " " + line_arr[3] + " bytes\n";
                        }
                    }
                    // above part reads every line and appends proper lines to the variable "result"
                    byte[] code = { 6 };
                    client.Send(code);

                    byte[] reqString = new byte[BUFFER_SIZE];
                    if (result == "")
                    { // if result is empty send proper response code back
                        reqString = Encoding.UTF8.GetBytes("156");
                        client.Send(reqString);
                    }
                    else
                    { // else, send resulting string to the client
                        reqString = Encoding.UTF8.GetBytes(result);
                        client.Send(reqString);
                    }
                    reader.Close();
                }
                logs.AppendText("The file list of " + userName + " is successfully sent to " + userName + ".\n");
            }

            catch (SocketException e)
            {
                if (!terminating)   // if user is disconnected, removes its name and socket from lists.
                {
                    logs.AppendText(userName + " has disconnected.\n");
                }
                client.Close();
                clientSockets.Remove(client);
                clientNames.Remove(userName);
                connected = false;
            }

            catch (IOException e)
            {
                logs.AppendText("An error related to file occurred during sending private file list " + userName + ".\n");
                // send response code
                byte[] code = { 2 };
                client.Send(code);
            }

            catch (Exception e)
            {
                logs.AppendText("An unknown error occurred during sending private file list " + userName + ".\n");
                // send response code
                byte[] code = { 2 };
                client.Send(code);
            }

            finally // NEWLY ADDED
            {
                databaseLock.ExitReadLock();
            }
        }

        private void MakePublic(string userName, Socket client, ref bool connected)
        { // given a name of file, this function makes this file public

            string toMakePublic = "";
            try
            {
                byte[] PubArray = new byte[BUFFER_SIZE];
                client.Receive(PubArray);
                toMakePublic = Encoding.UTF8.GetString(PubArray);
                toMakePublic = toMakePublic.Substring(0, toMakePublic.IndexOf('\0'));

                int found = 0;
                int lineNo = 0;
                string newLine = "";
                try // NEWLY ADDED
                {
                    databaseLock.EnterReadLock(); // NEWLY ADDED
                    sw.Close();
                    using (FileStream fs = new FileStream(@path2, FileMode.Open, FileAccess.Read, FileShare.Read))  //opening file to read
                    {
                        StreamReader reader = new StreamReader(fs); // start reading every line in database
                        string line;
                        while ((line = reader.ReadLine()) != null)
                        {
                            string[] line_arr = line.Split('\t');
                            string tempfile = line_arr[1];
                            if (tempfile.Equals(userName + "_" + toMakePublic + ".txt"))
                            { // if there is matching file
                                string trimmedLine = line.Substring(0, line.LastIndexOf('\t'));
                                newLine = trimmedLine + "\tpublic"; // add "public" to the end of the line
                                found = 1;
                                break; // there is no need to search more
                            }
                            lineNo++;
                        }
                        reader.Close();
                    }
                }
                catch // NEWLY ADDED
                {
                    found = -1; // NEWLY ADDED
                    logs.AppendText("An error related to database file occurred making a file public named " + toMakePublic + ".\n");
                    // send response code
                    byte[] code = { 25 };
                    client.Send(code);
                }
                finally // NEWLY ADDED 
                {
                    databaseLock.ExitReadLock();
                }
                
                if (found == 1)
                { // if there is such file
                    try
                    {
                        databaseLock.EnterWriteLock(); // NEWLY ADDED

                        var tempFile = Path.GetTempFileName();
                        string[] linesToKeep = File.ReadAllLines(path2);
                        linesToKeep[lineNo] = newLine; // change old line with the new one

                        File.WriteAllLines(tempFile, linesToKeep);

                        File.Delete(path2);
                        File.Move(tempFile, path2); // update database file

                        logs.AppendText(userName + " has made the file " + toMakePublic + " public.\n");
                        logs.AppendText("Database is successfully updated.\n"); // print proper messages

                        byte[] response = { 12 };
                        client.Send(response); // send proper response
                    }

                    catch (SocketException e)
                    {
                        if (!terminating)   // if user is disconnected, removes its name and socket from lists.
                        {
                            logs.AppendText(userName + " has disconnected.\n");
                        }
                        client.Close();
                        clientSockets.Remove(client);
                        clientNames.Remove(userName);
                        connected = false;
                    }

                    catch
                    {
                        logs.AppendText("An error related to file occurred making a file public named " + toMakePublic + ".\n");
                        // send response code
                        byte[] code = { 25 };
                        client.Send(code);
                    }

                    finally
                    {
                        databaseLock.ExitWriteLock();
                    }                  
                }
                else if (found == 0)
                { // if there is no such file to make public
                    byte[] response = { 13 };
                    client.Send(response); // send proper response
                    logs.AppendText(userName + " tried to make a non-existing file public: " + toMakePublic + ".\n"); // print proper message
                }
            }

            catch (SocketException e)
            {
                if (!terminating)   // if user is disconnected, removes its name and socket from lists.
                {
                    logs.AppendText(userName + " has disconnected.\n");
                }
                client.Close();
                clientSockets.Remove(client);
                clientNames.Remove(userName);
                connected = false;
            }

            catch
            {
                logs.AppendText("An error has occurred making a file public named " + toMakePublic + ".\n");
                // send response code
                byte[] code = { 25 };
                client.Send(code);
            }
        }

        private int publicDownloadCheck(string userName, string fileName)
        {
            /* Returns true if the given username owns the given public file name. */
            int exists = 0;
            try
            {
                databaseLock.EnterReadLock();
                sw.Close();
                string fileToCheck = userName + "_" + fileName + ".txt";
                using (FileStream fs = new FileStream(@path2, FileMode.Open, FileAccess.Read, FileShare.Read))  //opening file to read
                {
                    StreamReader reader = new StreamReader(fs);
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        string[] line_arr = line.Split('\t');
                        string tempFileName = line_arr[1];
                        string status = line_arr[4];
                        if (fileToCheck.Equals(tempFileName) && status.Equals("public"))
                        {
                            exists = 1;
                            break;
                        }
                    }
                    reader.Close();
                }
            }

            catch
            {
                logs.AppendText("An error has occurred during checking if the given public file name exists.\n");
                exists = -1;
            }

            finally
            {
                databaseLock.ExitReadLock();
            }

            return exists;
        }

        private int privateDownloadCheck(string userName, string fileName)
        {
            /* Returns true if the given file name is owned by the given user. */
            int exists = 0;
            try
            {
                databaseLock.EnterReadLock();
                sw.Close();
                string fileToCheck = userName + "_" + fileName + ".txt";
                using (FileStream fs = new FileStream(@path2, FileMode.Open, FileAccess.Read, FileShare.Read))  //opening file to read
                {
                    StreamReader reader = new StreamReader(fs);
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        string[] line_arr = line.Split('\t');
                        string tempFileName = line_arr[1];    // get the filename from the line
                        if (fileToCheck.Equals(tempFileName)) // compare
                        {
                            exists = 1;
                            break;
                        }
                    }
                    reader.Close();
                }            
            }

            catch
            {
                logs.AppendText("An error has occurred during checking if the given private file name exists.\n");
                exists = -1;
            }

            finally
            {
                databaseLock.ExitReadLock();
            }

            return exists;
        }

        private void sendPublicFileList(Socket thisClient, string userName, ref bool connected)
        {
            /* Sends the list of public files to the client. */
            try
            {
                databaseLock.EnterReadLock();
                sw.Close();
                using (FileStream fs = new FileStream(@path2, FileMode.Open, FileAccess.Read, FileShare.Read))  //opening file to read
                {
                    StreamReader reader = new StreamReader(fs);
                    string result = "";
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        string[] line_arr = line.Split('\t');
                        string status = line_arr[4];
                        string tempFileName = line_arr[1].Substring(line_arr[1].IndexOf('_') + 1);

                        // add the public files to result
                        if (status.Equals("public"))
                        {
                            result += line_arr[0] + " " + tempFileName + " " + line_arr[2] + " " + line_arr[3] + " bytes\n";
                        }
                    }

                    // send response the client in order to make client start receiving for the list
                    byte[] code = { 14 };
                    thisClient.Send(code);

                    byte[] reqString = new byte[BUFFER_SIZE]; // buffer byte array

                    // if there is no file in public list, send "156" to inform client
                    // otherwise, send the result
                    if (result == "") 
                    {
                        reqString = Encoding.UTF8.GetBytes("156");
                        thisClient.Send(reqString);
                    }
                    else
                    {
                        reqString = Encoding.UTF8.GetBytes(result);
                        thisClient.Send(reqString);
                    }
                    reader.Close();
                }

                logs.AppendText("The public files list is successfully sent to " + userName + ".\n");
            }

            catch (SocketException e)
            {
                if (!terminating)   // if user is disconnected, removes its name and socket from lists.
                {
                    logs.AppendText(userName + " has disconnected.\n");
                }
                thisClient.Close();
                clientSockets.Remove(thisClient);
                clientNames.Remove(userName);
                connected = false;
            }


            catch (IOException e)
            {
                logs.AppendText("An error related to database file occurred while sending public file list to " + userName + ".\n");
                // SEND RESPONSE --> FAILURE
                byte[] code = { 21 };
                thisClient.Send(code);
            }

            catch (Exception e)
            {
                logs.AppendText("An unknown error occurred during sending public file list.\n");
                logs.AppendText(e.Message);
                // SEND RESPONSE --> FAILURE
                byte[] code = { 21 };
                thisClient.Send(code);
            }

            finally
            {
                databaseLock.ExitReadLock();
            }
        }

        private void publicSendData(Socket thisClient, string requesterName, ref bool connected)
        {
            /* Sends a public file to the client.
             * 
             * 1 - Get the file name wanted to be downloaded and its owner from the client.
             * 
             * 2 - Check if the received user owns this public file.
             *  a. If it doesn't exist, inform the client w/ response code.
             *  b. If it exists, send the file to be downloaded chunk by chunk. 
             *  
             *******************************************************************************
             */
         
            try
            {
                // get the user name and file name by client
                byte[] nameDownload = new byte[BUFFER_SIZE];
                int dataLen = thisClient.Receive(nameDownload);
                if (dataLen == 0)
                    throw new SocketException(); // ???
                int nameDownloadSize = nameDownload.Length;
                int fileNameLen = BitConverter.ToInt32(nameDownload, 0);
                string fileToSendName = Encoding.UTF8.GetString(nameDownload, 4, fileNameLen);
                string username = Encoding.UTF8.GetString(nameDownload, 4 + fileNameLen, nameDownloadSize - (4 + fileNameLen));
                username = username.Substring(0, username.IndexOf('\0'));

                // check if the file exists
                int exists = publicDownloadCheck(username, fileToSendName);

                // it doesn't exist, send proper response code
                if (exists == -1)
                {
                    logs.AppendText("An error related to database file occurred while sending public file to " + requesterName + ".\n");
                    byte[] response = { 22 };
                    thisClient.Send(response);
                }

                else if (exists == 0)
                {
                    byte[] response = { 3 };
                    thisClient.Send(response);
                    logs.AppendText("The file " + fileToSendName + " doesn't exist.\n");
                }

                // it exists
                else if (exists == 1)
                {
                    fileToSendName += ".txt";
                    byte[] response = { 4 }; // serverside starts sending the file, inform the client
                    thisClient.Send(response);

                    // load the data in byte array, then send file size to the client
                    byte[] fileData;
                    fileData = File.ReadAllBytes(@fbd.SelectedPath + "\\" + username + "_" + fileToSendName);

                    byte[] fileSize = BitConverter.GetBytes(fileData.Length);
                    thisClient.Send(fileSize);

                    // total data amount is stored in dataToSend
                    int dataToSend = BitConverter.ToInt32(fileSize, 0);

                    // synchronization purposes
                    byte[] start = new byte[1];
                    thisClient.Receive(start);

                    int offset = 0;
                    while (dataToSend > 0)
                    { // for big files, keep sending data as long as there is data so send
                        int size = Math.Min(dataToSend, BUFFER_SIZE);
                        int bytesSent = thisClient.Send(fileData, offset, size, 0);
                        if (bytesSent == 0)
                            throw new SocketException(); // ???
                        dataToSend -= bytesSent;
                        offset += bytesSent;
                    }

                    logs.AppendText("The file " + fileToSendName + " is successfully sent to " + requesterName + ".\n");
                }

            }

            catch (SocketException e)
            {
                if (!terminating)   // if user is disconnected, removes its name and socket from lists.
                {
                    logs.AppendText(requesterName + " has disconnected.\n");
                }
                thisClient.Close();
                clientSockets.Remove(thisClient);
                clientNames.Remove(requesterName);
                connected = false;
            }
            catch (IOException e)
            {
                logs.AppendText("An error related to database file occurred while sending public file to " + requesterName + ".\n");
                byte[] code = { 22 };
                thisClient.Send(code);
            }
            catch (Exception e)
            {
                logs.AppendText("An unknown error occurred during sending public file to " + requesterName + ".\n");
                byte[] code = { 22 };
                thisClient.Send(code);
            }
        }


        private void sendPrivateData(Socket client, string userName, ref bool connected)
        {
            /* Sends a private file to the client.
             * 
             * 1 - Get the file name wanted to be downloaded and its owner from the client.
             * 
             * 2 - Check if the received file is owned by the given username.
             *  a. If it doesn't exist, inform the client w/ response code.
             *  b. If it exists, send the file to be downloaded chunk by chunk. 
             *  
             *******************************************************************************
             */

            try
            {
                // get the name of the file
                byte[] nameDownload = new byte[BUFFER_SIZE];
                client.Receive(nameDownload);
                string fileToSendName = Encoding.UTF8.GetString(nameDownload);
                fileToSendName = fileToSendName.Substring(0, fileToSendName.IndexOf('\0'));

                // check if the file exists
                int exists = privateDownloadCheck(userName, fileToSendName);

                if (exists == -1)
                {
                    logs.AppendText("An error related to database file occurred while sending private file to " + userName + ".\n");
                    byte[] code = { 23 };
                    client.Send(code);
                }

                // inform user it doesn't exist
                else if (exists == 0)
                {
                    byte[] response = { 15 };
                    client.Send(response);
                    logs.AppendText("The file " + fileToSendName + " doesn't exist.\n");
                }

                else if (exists == 1)
                {
                    fileToSendName += ".txt";
                    byte[] response = { 16 };
                    client.Send(response);

                    // load the data of the file to byte array and send the file size to client
                    byte[] fileData;
                    fileData = File.ReadAllBytes(@fbd.SelectedPath + "\\" + userName + "_" + fileToSendName);

                    byte[] fileSize = BitConverter.GetBytes(fileData.Length);
                    client.Send(fileSize);

                    // total data amount is stored in dataToSend
                    int dataToSend = BitConverter.ToInt32(fileSize, 0);

                    // synchronization purposes
                    byte[] start = new byte[1];
                    client.Receive(start);

                    int offset = 0;
                    while (dataToSend > 0)
                    { // for big files, keep sending data as long as there is data so send
                        int size = Math.Min(dataToSend, BUFFER_SIZE);
                        int bytesSent = client.Send(fileData, offset, size, 0);
                        dataToSend -= bytesSent;
                        offset += bytesSent;
                    }

                    logs.AppendText("The file " + fileToSendName + " is successfully sent to " + userName + ".\n");
                }
            }

            catch (SocketException e)
            {
                if (!terminating)   // if user is disconnected, removes its name and socket from lists.
                {
                    logs.AppendText(userName + " has disconnected.\n");
                }
                client.Close();
                clientSockets.Remove(client);
                clientNames.Remove(userName);
                connected = false;
            }
            catch (IOException e)
            {
                logs.AppendText("An error related to database file occurred while sending private file to " + userName + ".\n");
                byte[] code = { 23 };
                client.Send(code);
            } 
            catch (Exception e)
            {
                logs.AppendText("An unknown error occurred during sending private file to " + userName + ".\n");
                byte[] code = { 23 };
                client.Send(code);
            }
        }
    }
}
