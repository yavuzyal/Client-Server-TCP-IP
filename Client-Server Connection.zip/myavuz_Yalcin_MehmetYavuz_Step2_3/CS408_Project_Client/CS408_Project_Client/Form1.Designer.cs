﻿namespace CS408_Project_Client
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_ip = new System.Windows.Forms.TextBox();
            this.textBox_port = new System.Windows.Forms.TextBox();
            this.textBox_username = new System.Windows.Forms.TextBox();
            this.button_connect = new System.Windows.Forms.Button();
            this.logs = new System.Windows.Forms.RichTextBox();
            this.button_send = new System.Windows.Forms.Button();
            this.button_disconnect = new System.Windows.Forms.Button();
            this.textBox_download = new System.Windows.Forms.TextBox();
            this.button_download = new System.Windows.Forms.Button();
            this.textBox_location = new System.Windows.Forms.TextBox();
            this.button_loc_browse = new System.Windows.Forms.Button();
            this.button_request = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.button_public = new System.Windows.Forms.Button();
            this.textBox_public = new System.Windows.Forms.TextBox();
            this.button_public_req = new System.Windows.Forms.Button();
            this.textBox_download_user = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox_private_filename = new System.Windows.Forms.TextBox();
            this.button_private_download = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox_file = new System.Windows.Forms.TextBox();
            this.button_browse = new System.Windows.Forms.Button();
            this.button_copy = new System.Windows.Forms.Button();
            this.textBox_copy = new System.Windows.Forms.TextBox();
            this.textBox_delete = new System.Windows.Forms.TextBox();
            this.button_delete = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(15, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(24, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "IP:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(15, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Port:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(15, 105);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Username:";
            // 
            // textBox_ip
            // 
            this.textBox_ip.Location = new System.Drawing.Point(100, 38);
            this.textBox_ip.Name = "textBox_ip";
            this.textBox_ip.Size = new System.Drawing.Size(131, 23);
            this.textBox_ip.TabIndex = 3;
            // 
            // textBox_port
            // 
            this.textBox_port.Location = new System.Drawing.Point(100, 69);
            this.textBox_port.Name = "textBox_port";
            this.textBox_port.Size = new System.Drawing.Size(131, 23);
            this.textBox_port.TabIndex = 4;
            // 
            // textBox_username
            // 
            this.textBox_username.Location = new System.Drawing.Point(100, 98);
            this.textBox_username.Name = "textBox_username";
            this.textBox_username.Size = new System.Drawing.Size(131, 23);
            this.textBox_username.TabIndex = 5;
            // 
            // button_connect
            // 
            this.button_connect.Location = new System.Drawing.Point(100, 129);
            this.button_connect.Name = "button_connect";
            this.button_connect.Size = new System.Drawing.Size(131, 35);
            this.button_connect.TabIndex = 6;
            this.button_connect.Text = "Connect";
            this.button_connect.UseVisualStyleBackColor = true;
            this.button_connect.Click += new System.EventHandler(this.button_connect_Click);
            // 
            // logs
            // 
            this.logs.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.logs.Location = new System.Drawing.Point(886, 12);
            this.logs.Name = "logs";
            this.logs.ReadOnly = true;
            this.logs.Size = new System.Drawing.Size(358, 477);
            this.logs.TabIndex = 8;
            this.logs.Text = "";
            // 
            // button_send
            // 
            this.button_send.Enabled = false;
            this.button_send.Location = new System.Drawing.Point(508, 22);
            this.button_send.Name = "button_send";
            this.button_send.Size = new System.Drawing.Size(86, 26);
            this.button_send.TabIndex = 11;
            this.button_send.Text = "Send";
            this.button_send.UseVisualStyleBackColor = true;
            this.button_send.Click += new System.EventHandler(this.button_send_Click);
            // 
            // button_disconnect
            // 
            this.button_disconnect.Enabled = false;
            this.button_disconnect.Location = new System.Drawing.Point(100, 169);
            this.button_disconnect.Margin = new System.Windows.Forms.Padding(2);
            this.button_disconnect.Name = "button_disconnect";
            this.button_disconnect.Size = new System.Drawing.Size(131, 35);
            this.button_disconnect.TabIndex = 12;
            this.button_disconnect.Text = "Disconnect";
            this.button_disconnect.UseVisualStyleBackColor = true;
            this.button_disconnect.Click += new System.EventHandler(this.button_disconnect_Click);
            // 
            // textBox_download
            // 
            this.textBox_download.Enabled = false;
            this.textBox_download.Location = new System.Drawing.Point(205, 64);
            this.textBox_download.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_download.Name = "textBox_download";
            this.textBox_download.Size = new System.Drawing.Size(270, 23);
            this.textBox_download.TabIndex = 15;
            // 
            // button_download
            // 
            this.button_download.Enabled = false;
            this.button_download.Location = new System.Drawing.Point(485, 29);
            this.button_download.Margin = new System.Windows.Forms.Padding(2);
            this.button_download.Name = "button_download";
            this.button_download.Size = new System.Drawing.Size(111, 58);
            this.button_download.TabIndex = 16;
            this.button_download.Text = "Download";
            this.button_download.UseVisualStyleBackColor = true;
            this.button_download.Click += new System.EventHandler(this.button_download_Click);
            // 
            // textBox_location
            // 
            this.textBox_location.Enabled = false;
            this.textBox_location.Location = new System.Drawing.Point(204, 18);
            this.textBox_location.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_location.Name = "textBox_location";
            this.textBox_location.Size = new System.Drawing.Size(270, 23);
            this.textBox_location.TabIndex = 17;
            // 
            // button_loc_browse
            // 
            this.button_loc_browse.Enabled = false;
            this.button_loc_browse.Location = new System.Drawing.Point(484, 16);
            this.button_loc_browse.Margin = new System.Windows.Forms.Padding(2);
            this.button_loc_browse.Name = "button_loc_browse";
            this.button_loc_browse.Size = new System.Drawing.Size(111, 29);
            this.button_loc_browse.TabIndex = 18;
            this.button_loc_browse.Text = "Browse";
            this.button_loc_browse.UseVisualStyleBackColor = true;
            this.button_loc_browse.Click += new System.EventHandler(this.button_loc_browse_Click);
            // 
            // button_request
            // 
            this.button_request.Enabled = false;
            this.button_request.Location = new System.Drawing.Point(100, 208);
            this.button_request.Margin = new System.Windows.Forms.Padding(2);
            this.button_request.Name = "button_request";
            this.button_request.Size = new System.Drawing.Size(131, 39);
            this.button_request.TabIndex = 21;
            this.button_request.Text = "Request File List";
            this.button_request.UseVisualStyleBackColor = true;
            this.button_request.Click += new System.EventHandler(this.button_request_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(5, 21);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(168, 17);
            this.label7.TabIndex = 25;
            this.label7.Text = "Select download location:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(5, 67);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(183, 17);
            this.label8.TabIndex = 26;
            this.label8.Text = "Enter filename to download:";
            // 
            // button_public
            // 
            this.button_public.Enabled = false;
            this.button_public.Location = new System.Drawing.Point(485, 21);
            this.button_public.Name = "button_public";
            this.button_public.Size = new System.Drawing.Size(111, 24);
            this.button_public.TabIndex = 27;
            this.button_public.Text = "Make Public";
            this.button_public.UseVisualStyleBackColor = true;
            this.button_public.Click += new System.EventHandler(this.button_public_Click);
            // 
            // textBox_public
            // 
            this.textBox_public.Enabled = false;
            this.textBox_public.Location = new System.Drawing.Point(205, 21);
            this.textBox_public.Name = "textBox_public";
            this.textBox_public.Size = new System.Drawing.Size(270, 23);
            this.textBox_public.TabIndex = 28;
            // 
            // button_public_req
            // 
            this.button_public_req.Enabled = false;
            this.button_public_req.Location = new System.Drawing.Point(100, 251);
            this.button_public_req.Margin = new System.Windows.Forms.Padding(2);
            this.button_public_req.Name = "button_public_req";
            this.button_public_req.Size = new System.Drawing.Size(131, 41);
            this.button_public_req.TabIndex = 29;
            this.button_public_req.Text = "Request Public Files";
            this.button_public_req.UseVisualStyleBackColor = true;
            this.button_public_req.Click += new System.EventHandler(this.button_public_req_Click);
            // 
            // textBox_download_user
            // 
            this.textBox_download_user.Enabled = false;
            this.textBox_download_user.Location = new System.Drawing.Point(205, 29);
            this.textBox_download_user.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_download_user.Name = "textBox_download_user";
            this.textBox_download_user.Size = new System.Drawing.Size(270, 23);
            this.textBox_download_user.TabIndex = 30;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(5, 32);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(174, 17);
            this.label9.TabIndex = 31;
            this.label9.Text = "Enter the owner of the file:";
            // 
            // textBox_private_filename
            // 
            this.textBox_private_filename.Enabled = false;
            this.textBox_private_filename.Location = new System.Drawing.Point(204, 21);
            this.textBox_private_filename.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_private_filename.Name = "textBox_private_filename";
            this.textBox_private_filename.Size = new System.Drawing.Size(270, 23);
            this.textBox_private_filename.TabIndex = 33;
            // 
            // button_private_download
            // 
            this.button_private_download.Enabled = false;
            this.button_private_download.Location = new System.Drawing.Point(484, 17);
            this.button_private_download.Margin = new System.Windows.Forms.Padding(2);
            this.button_private_download.Name = "button_private_download";
            this.button_private_download.Size = new System.Drawing.Size(111, 31);
            this.button_private_download.TabIndex = 34;
            this.button_private_download.Text = "Download";
            this.button_private_download.UseVisualStyleBackColor = true;
            this.button_private_download.Click += new System.EventHandler(this.button_private_download_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(5, 25);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(183, 17);
            this.label10.TabIndex = 35;
            this.label10.Text = "Enter filename to download:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(3, 24);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(198, 17);
            this.label11.TabIndex = 36;
            this.label11.Text = "Enter filename to make public:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Khaki;
            this.label12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(110, 315);
            this.label12.Name = "label12";
            this.label12.Padding = new System.Windows.Forms.Padding(6, 23, 6, 23);
            this.label12.Size = new System.Drawing.Size(107, 167);
            this.label12.TabIndex = 37;
            this.label12.Text = " IMPORTANT\r\n  Enter every\r\n    filename\r\n     as the\r\n   following\r\n   example:\r\n" +
    "  fileName_1";
            // 
            // textBox_file
            // 
            this.textBox_file.Enabled = false;
            this.textBox_file.Location = new System.Drawing.Point(203, 25);
            this.textBox_file.Name = "textBox_file";
            this.textBox_file.Size = new System.Drawing.Size(204, 23);
            this.textBox_file.TabIndex = 9;
            // 
            // button_browse
            // 
            this.button_browse.Enabled = false;
            this.button_browse.Location = new System.Drawing.Point(413, 22);
            this.button_browse.Name = "button_browse";
            this.button_browse.Size = new System.Drawing.Size(86, 26);
            this.button_browse.TabIndex = 10;
            this.button_browse.Text = "Browse";
            this.button_browse.UseVisualStyleBackColor = true;
            this.button_browse.Click += new System.EventHandler(this.button_browse_Click);
            // 
            // button_copy
            // 
            this.button_copy.Enabled = false;
            this.button_copy.Location = new System.Drawing.Point(484, 21);
            this.button_copy.Margin = new System.Windows.Forms.Padding(2);
            this.button_copy.Name = "button_copy";
            this.button_copy.Size = new System.Drawing.Size(111, 29);
            this.button_copy.TabIndex = 13;
            this.button_copy.Text = "Create Copy";
            this.button_copy.UseVisualStyleBackColor = true;
            this.button_copy.Click += new System.EventHandler(this.button_copy_Click);
            // 
            // textBox_copy
            // 
            this.textBox_copy.Enabled = false;
            this.textBox_copy.Location = new System.Drawing.Point(204, 25);
            this.textBox_copy.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_copy.Name = "textBox_copy";
            this.textBox_copy.Size = new System.Drawing.Size(270, 23);
            this.textBox_copy.TabIndex = 14;
            // 
            // textBox_delete
            // 
            this.textBox_delete.Enabled = false;
            this.textBox_delete.Location = new System.Drawing.Point(204, 27);
            this.textBox_delete.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_delete.Name = "textBox_delete";
            this.textBox_delete.Size = new System.Drawing.Size(270, 23);
            this.textBox_delete.TabIndex = 19;
            // 
            // button_delete
            // 
            this.button_delete.Enabled = false;
            this.button_delete.Location = new System.Drawing.Point(484, 24);
            this.button_delete.Margin = new System.Windows.Forms.Padding(2);
            this.button_delete.Name = "button_delete";
            this.button_delete.Size = new System.Drawing.Size(111, 29);
            this.button_delete.TabIndex = 20;
            this.button_delete.Text = "Delete";
            this.button_delete.UseVisualStyleBackColor = true;
            this.button_delete.Click += new System.EventHandler(this.button_delete_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(5, 28);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(136, 17);
            this.label4.TabIndex = 22;
            this.label4.Text = "Select a file to send:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(5, 28);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(153, 17);
            this.label5.TabIndex = 23;
            this.label5.Text = "Enter filename to copy:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(5, 34);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(162, 17);
            this.label6.TabIndex = 24;
            this.label6.Text = "Enter filename to delete:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.textBox_file);
            this.groupBox1.Controls.Add(this.button_browse);
            this.groupBox1.Controls.Add(this.button_send);
            this.groupBox1.Location = new System.Drawing.Point(270, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(610, 66);
            this.groupBox1.TabIndex = 38;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Send a File";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.button_copy);
            this.groupBox2.Controls.Add(this.textBox_copy);
            this.groupBox2.Location = new System.Drawing.Point(269, 84);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(611, 66);
            this.groupBox2.TabIndex = 39;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Copy a File";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.textBox_delete);
            this.groupBox3.Controls.Add(this.button_delete);
            this.groupBox3.Location = new System.Drawing.Point(269, 156);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(611, 66);
            this.groupBox3.TabIndex = 40;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Delete a File";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.textBox_location);
            this.groupBox4.Controls.Add(this.button_loc_browse);
            this.groupBox4.Location = new System.Drawing.Point(269, 228);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(611, 50);
            this.groupBox4.TabIndex = 41;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Download a File";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label10);
            this.groupBox5.Controls.Add(this.textBox_private_filename);
            this.groupBox5.Controls.Add(this.button_private_download);
            this.groupBox5.Location = new System.Drawing.Point(269, 274);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(611, 54);
            this.groupBox5.TabIndex = 42;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Private File Download";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label9);
            this.groupBox6.Controls.Add(this.textBox_download_user);
            this.groupBox6.Controls.Add(this.label8);
            this.groupBox6.Controls.Add(this.textBox_download);
            this.groupBox6.Controls.Add(this.button_download);
            this.groupBox6.Location = new System.Drawing.Point(268, 334);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(612, 95);
            this.groupBox6.TabIndex = 42;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Public File Download";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.label11);
            this.groupBox7.Controls.Add(this.textBox_public);
            this.groupBox7.Controls.Add(this.button_public);
            this.groupBox7.Location = new System.Drawing.Point(268, 435);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(612, 54);
            this.groupBox7.TabIndex = 43;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Make a File Public";
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1253, 499);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.button_public_req);
            this.Controls.Add(this.button_request);
            this.Controls.Add(this.button_disconnect);
            this.Controls.Add(this.logs);
            this.Controls.Add(this.button_connect);
            this.Controls.Add(this.textBox_username);
            this.Controls.Add(this.textBox_port);
            this.Controls.Add(this.textBox_ip);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Navy;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "Form1";
            this.Text = "Client";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_ip;
        private System.Windows.Forms.TextBox textBox_port;
        private System.Windows.Forms.TextBox textBox_username;
        private System.Windows.Forms.Button button_connect;
        private System.Windows.Forms.RichTextBox logs;
        private System.Windows.Forms.Button button_send;
        private System.Windows.Forms.Button button_disconnect;
        private System.Windows.Forms.TextBox textBox_download;
        private System.Windows.Forms.Button button_download;
        private System.Windows.Forms.TextBox textBox_location;
        private System.Windows.Forms.Button button_loc_browse;
        private System.Windows.Forms.Button button_request;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button_public;
        private System.Windows.Forms.TextBox textBox_public;
        private System.Windows.Forms.Button button_public_req;
        private System.Windows.Forms.TextBox textBox_download_user;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox_private_filename;
        private System.Windows.Forms.Button button_private_download;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox_file;
        private System.Windows.Forms.Button button_browse;
        private System.Windows.Forms.Button button_copy;
        private System.Windows.Forms.TextBox textBox_copy;
        private System.Windows.Forms.TextBox textBox_delete;
        private System.Windows.Forms.Button button_delete;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox7;
    }
}

