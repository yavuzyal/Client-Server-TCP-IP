﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CS408_Project_Client
{
    public partial class Form1 : Form
    {
        private static string shortFileName = "";
        private static string fileName = ""; // for sending files
        private static string downloadLocation = "";

        string IP;
        int portNum; // IP and portnum are for connecting to the server
        const int BUFFER_SIZE = 2048; // used for sending data

        FolderBrowserDialog fbd = new FolderBrowserDialog();

        bool terminating = false;
        bool connected = false;
        bool disconnected = false; // booleans to be used in threads
        Socket clientSocket;
        public Form1()
        {
            Control.CheckForIllegalCrossThreadCalls = false;
            this.FormClosing += new FormClosingEventHandler(Form1_FormClosing);
            InitializeComponent();
        }

        private void button_connect_Click(object sender, EventArgs e)
        { // when connect button is clicked
            clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            IP = textBox_ip.Text;// retreive ip information from the box

            if (Int32.TryParse(textBox_port.Text, out portNum)) // parse port number, if possible assign it
            { //executed when port number is valid
                try
                {
                    string username = textBox_username.Text; // retrieve username

                    if (username != "" && !username.Contains("_") && username.Length < 100)
                    { // if username is not empty
                        clientSocket.Connect(IP, portNum);
                        Byte[] namebuffer = new Byte[64];
                        namebuffer = Encoding.UTF8.GetBytes(username);
                        clientSocket.Send(namebuffer);
                        // connect to the server and send username
                        Byte[] recbuffer = new Byte[64];
                        clientSocket.Receive(recbuffer);
                        // receive server's response
                        string response = Encoding.UTF8.GetString(recbuffer);
                        response = response.Substring(0, response.IndexOf("\0"));
                        // parse the response message
                        if (response.Equals("0"))
                        { // response being 0 means server rejected the request
                            logs.AppendText("There is already a different user with username: " + username + "\n");
                            clientSocket.Close();
                            connected = false;
                        }
                        else
                        { // if server accepts connection
                            button_disconnect.Enabled = true;
                            button_connect.Enabled = false;
                            button_browse.Enabled = true;
                            //button_send.Enabled = true;
                            button_copy.Enabled = true;
                            button_delete.Enabled = true;
                            //button_download.Enabled = true;
                            button_request.Enabled = true;
                            button_public_req.Enabled = true;
                            button_public.Enabled = true;
                            button_loc_browse.Enabled = true;
                            textBox_copy.Enabled = true;
                            textBox_delete.Enabled = true;
                            //textBox_download.Enabled = true;
                            textBox_file.Enabled = true;
                            textBox_location.Enabled = true;
                            textBox_public.Enabled = true;

                            // set buttons
                            connected = true;
                            disconnected = false; // set booleans for threads
                            logs.AppendText("You are connected to the server!\n");
                            Thread receiveThread = new Thread(Receive);
                            receiveThread.Start(); // start trying to receive messages from server so that
                            //                        it is possible to detect connection
                        }
                    }

                    else if (username.Contains("_"))
                    { // usernames contaning underscore may confuse database operations
                        // if there is a underscore a pop up message is shown to make user re-enter a different username
                        System.Windows.Forms.MessageBox.Show("Username cannot contain the character _ (underscore).\n", "Try Again");
                    }

                    else
                    { // if username box is empty
                        logs.AppendText("You have to provide a username.\n");
                    }
                }
                catch
                {
                    logs.AppendText("Could not connect to the server!\n");
                }
            }
            else
            {
                logs.AppendText("Invalid port number.\n");
            }
        }
        private void Form1_FormClosing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            connected = false;
            terminating = true;
            Environment.Exit(0);
        }

        private void Receive()
        { // tries to receive messages from server
            while (connected) // as long as client is connected to the server
            {
                try // PUT CATCH BLOCKS ACCORDINGLY!!!!!!!!!!!!!!!!!!!!
                {
                    byte[] buffer = new byte[4];
                    clientSocket.Receive(buffer); // it constantly waits here to receive something
                    int responseCode = BitConverter.ToInt32(buffer, 0);

                    // start of responses of create copy function
                    if (responseCode == 20) {
                        logs.AppendText("The file you want to copy doesn't exist.\n");
                        openButtons();
                    }
                       
                    else if (responseCode == 1) {
                        logs.AppendText("The copy of the file is successfully created.\n");
                        openButtons();
                    }
                        
                    else if (responseCode == 2) {
                        logs.AppendText("An error at the server side occurred.\n");
                        openButtons();
                    }
                       
                    // end of responses of create copy function

                    // start of responses of public download function
                    else if (responseCode == 3) {
                        logs.AppendText("The file you want to download doesn't exist.\n");
                        openButtons();
                    }

                    else if (responseCode == 4)
                    {
                        downloadFile();
                        openButtons();
                    }

                    else if (responseCode == 22)
                    {
                        logs.AppendText("An error occurred on serverside during receiving a public file.\n");
                        openButtons();
                    }
                    // end of public download function

                    // request file list
                    else if (responseCode == 6)
                    {
                        byte[] message = new byte[BUFFER_SIZE];
                        clientSocket.Receive(message);
                        string msg = Encoding.UTF8.GetString(message);
                        msg = msg.Substring(0, msg.IndexOf('\0'));

                        if (msg.Equals("156"))
                            logs.AppendText("You have no files on the cloud.\n");
                        else {
                            logs.AppendText("Your File List:\n----------------------\n");
                            logs.AppendText(msg);
                        }
                        openButtons();
                    }

                    // start of delete
                    else if (responseCode == 10)
                    {
                        logs.AppendText("The file is successfully deleted.\n");
                        openButtons();
                    }
                    else if (responseCode == 11)
                    {
                        logs.AppendText("The file you want to delete doesn't exist.\n");
                        openButtons();
                    }
                    // end of delete

                    // start of make public
                    else if (responseCode == 12)
                    {
                        logs.AppendText("File has been made public successfully.\n");
                        openButtons();
                    }
                    else if (responseCode == 13)
                    {
                        logs.AppendText("This file you want to make public does not exist.\n");
                        openButtons();
                    }

                    else if (responseCode == 25)
                    {
                        logs.AppendText("An error occurred during making a file public.\n");
                        openButtons();
                    }
                    // end of make public

                    // start of public file list
                    else if (responseCode == 14)
                    {
                        byte[] message = new byte[BUFFER_SIZE];
                        clientSocket.Receive(message);
                        string msg = Encoding.UTF8.GetString(message);
                        msg = msg.Substring(0, msg.IndexOf('\0'));

                        if (msg.Equals("156"))
                            logs.AppendText("There is no public file on the cloud.\n");
                        else
                        {
                            logs.AppendText("Public File List:\n----------------------\n");
                            logs.AppendText(msg);
                        }
                        openButtons();
                    }

                    // failure
                    else if (responseCode == 21)
                    {
                        logs.AppendText("An error occurred on serverside during receiving public file list.\n");
                        openButtons();
                    }
                    // end of public file list

                    // start of private download data
                    // file doesn't exist
                    else if (responseCode == 15)
                    {
                        logs.AppendText("The file you want to download doesn't exist.\n");
                        openButtons();
                    }

                    // start download
                    else if (responseCode == 16)
                    {
                        downloadFile();
                        openButtons();
                    }

                    // error
                    else if (responseCode == 23)
                    {
                        logs.AppendText("An error occurred on serverside during receiving a private file.\n");
                        openButtons();
                    }

                    // end of private download data

                    // send file
                    else if (responseCode == 105)
                    {
                        SendFile();
                    }

                    // success
                    else if (responseCode == 18)
                    {
                        logs.AppendText(shortFileName + " sent successfully.\n");
                        openButtons();
                    }

                    // failure
                    else if (responseCode == 19)
                    {
                        logs.AppendText("An error occurred on serverside during sending " + shortFileName + ".\n");
                        openButtons();
                    }
                    // end of send file

                }
                catch
                { // if cannot receive then there are 2 options
                    if (disconnected) // if client is disconnected himself
                    {
                        logs.AppendText("Successfully disconnected from the server.\n");
                    }
                    else if (!terminating) // if there is a problem with server
                    { // server is closed probably
                        logs.AppendText("The server has disconnected.\n"); 
                    }
                    button_disconnect.Enabled = false;
                    button_connect.Enabled = true;
                    button_browse.Enabled = false;
                    button_send.Enabled = false;
                    button_copy.Enabled = false;
                    button_delete.Enabled = false;
                    button_download.Enabled = false;
                    button_request.Enabled = false;
                    button_public.Enabled = false;
                    button_public_req.Enabled = false;
                    button_loc_browse.Enabled = false;
                    textBox_copy.Enabled = false;
                    textBox_delete.Enabled = false;
                    textBox_download.Enabled = false;
                    textBox_file.Enabled = false;
                    textBox_location.Enabled = false;
                    textBox_public.Enabled = false;

                    connected = false;
                    clientSocket.Close(); // close the client socket
                }

            }
        }

        private void button_browse_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog(); // creating a new file dialog
            dlg.Title = "Choose a file to upload";
            dlg.ShowDialog();
            textBox_file.Text = dlg.FileName;
            fileName = dlg.FileName;
            shortFileName = dlg.SafeFileName; // assign file variables for later usage
            if (textBox_file.Text != "") {               
                button_send.Enabled = true;
            }
            
        }

        private void button_send_Click(object sender, EventArgs e)
        { // this function is for sending files, called when send button is clicked
          // close send button until everything is sent to the server
            closeButtons();
            string fileName = textBox_file.Text;
            if (fileName != "") // if a file is selected
            {
                byte[] functionByte = { 1 };
                clientSocket.Send(functionByte);
            }
            else
            {
                logs.AppendText("You have to select a file first.\n");
            }
        }

        private void SendFile()
        {
            try
            {
                // collect related information for file sending

                byte[] fileData = File.ReadAllBytes(fileName);
                byte[] fileNameByte = Encoding.UTF8.GetBytes(shortFileName);
                byte[] sizeAndFileName = new byte[4 + fileNameByte.Length + 4];

                byte[] fileNameLen = BitConverter.GetBytes(fileNameByte.Length);
                byte[] fileSize = BitConverter.GetBytes(fileData.Length);

                fileNameLen.CopyTo(sizeAndFileName, 0); // put file information into byte array
                fileNameByte.CopyTo(sizeAndFileName, 4);
                fileSize.CopyTo(sizeAndFileName, 4 + fileNameByte.Length);

                // first send file size and file name to server for arrangements
                clientSocket.Send(sizeAndFileName, sizeAndFileName.Length, SocketFlags.None);

                // total data amount is stored in dataToSend
                int dataToSend = BitConverter.ToInt32(fileSize, 0);
  
                int offset = 0;
                while (dataToSend > 0)
                { // for big files, keep sending data as long as there is data so send
                    int size = Math.Min(dataToSend, BUFFER_SIZE);
                    int bytesSent = clientSocket.Send(fileData, offset, size, 0);
                    dataToSend -= bytesSent;
                    offset += bytesSent;
                }
            }
            catch (SocketException ex)
            {
                logs.AppendText("Socket Error!\n");
            }
            catch (ArgumentNullException ex)
            {
                logs.AppendText("Invalid argument!\n");
            }
            catch (ArgumentOutOfRangeException ex)
            {
                logs.AppendText("Argument out of range!\n");
            }
            catch (ObjectDisposedException ex)
            {
                logs.AppendText("Invalid operation!\n");
            }
            catch
            {
                logs.AppendText("File could not be sent.\n");
            }
        }

        private void closeButtons()
        { // this function disables button in order to prevent conflicts on server side
            button_send.Enabled = false;
            button_browse.Enabled = false;
            button_copy.Enabled = false;
            button_delete.Enabled = false;
            button_download.Enabled = false;
            button_request.Enabled = false;
            button_loc_browse.Enabled = false;
            button_public.Enabled = false;
            button_public_req.Enabled = false;
            button_private_download.Enabled = false;
        }

        private void openButtons()
        { // enables button so that they can be used again
            button_send.Enabled = true;
            button_browse.Enabled = true;
            button_copy.Enabled = true;
            button_delete.Enabled = true;
            button_download.Enabled = true;
            button_request.Enabled = true;
            button_public_req.Enabled = true;
            button_public.Enabled = true;
            button_loc_browse.Enabled = true;
            button_private_download.Enabled = true;
        }

        // UPDATES !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        private void button_disconnect_Click(object sender, EventArgs e)
        { // invoked when disconnect button is clicked
            button_disconnect.Enabled = false;
            button_connect.Enabled = true;
            button_browse.Enabled = false;
            button_send.Enabled = false;
            button_copy.Enabled = false;
            button_delete.Enabled = false;
            button_download.Enabled = false;
            button_request.Enabled = false;
            button_loc_browse.Enabled = false;
            button_public.Enabled = false;
            button_public_req.Enabled = false;
            button_private_download.Enabled = false;

            textBox_copy.Enabled = false;
            textBox_delete.Enabled = false;
            textBox_download.Enabled = false;
            textBox_file.Enabled = false;
            textBox_location.Enabled = false;
            textBox_public.Enabled = false;
            textBox_download_user.Enabled = false;
            textBox_private_filename.Enabled = false;

            textBox_copy.Clear();
            textBox_delete.Clear();
            textBox_file.Clear();
            textBox_download.Clear();
            textBox_location.Clear();
            textBox_public.Clear();
            textBox_private_filename.Clear();
            textBox_download_user.Clear();
            
            disconnected = true;
            connected = false; // set button and booleans correctly
            clientSocket.Close(); // close the client sockets
        }

        private void button_copy_Click(object sender, EventArgs e)
        { // this function is invoked when copy button is clicked
            string fileToBeCopied = textBox_copy.Text; // take the name of file to be copied
            if (fileToBeCopied == "")
            { // if cannot be empty
                logs.AppendText("You must enter a file name to send copy request.\n");
            }
            else if (!fileToBeCopied.Contains("_"))
            { // it cannot contain underscore, it confuses database management on server side
                System.Windows.Forms.MessageBox.Show("The name of the file you want to copy cannot contain the character _ (underscore).\n", "Try Again");
            }
            else
            { // if there are no problems start copying precedure
                closeButtons();
                byte[] functionByte = { 3 };
                byte[] copyTextByte = Encoding.UTF8.GetBytes(fileToBeCopied);
                clientSocket.Send(functionByte);
                clientSocket.Send(copyTextByte);
            }
        }

        private void button_loc_browse_Click(object sender, EventArgs e)
        { // this function is for users to select location for downloading files
            fbd.RootFolder = Environment.SpecialFolder.MyComputer;  // making the rootfolder for folder searching My Computer.
            fbd.Description = "Select Folder";
            fbd.ShowNewFolderButton = false;

            if (fbd.ShowDialog() == DialogResult.OK)    // if client side chose the folder.
            {
                textBox_location.Text = fbd.SelectedPath;   // Show the path on textBox.
                textBox_download.Enabled = true;
                button_download.Enabled = true;
                textBox_download_user.Enabled = true;
                button_private_download.Enabled = true;
                textBox_private_filename.Enabled = true;
            }
        }

        private void button_download_Click(object sender, EventArgs e)
        { // invoked when user wants to download a PUBLIC file from the server
            // send the download request and name of the file to be downloaded
            downloadLocation = textBox_download.Text;
            string username = textBox_download_user.Text;
            if (downloadLocation == "")
            {
                logs.AppendText("You must enter a file name to send a download request.\n");
            }
            else if (username == "")
            {
                logs.AppendText("You must enter a username to send a download request.\n");
            }
            else
            {
                closeButtons();
                byte[] functionByte = { 2 };
                byte[] fileNameByte = Encoding.UTF8.GetBytes(downloadLocation);
                byte[] userNameByte = Encoding.UTF8.GetBytes(username);

                // loading user name and file name to a byte array
                byte[] downloadUserNameByte = new byte[4 + fileNameByte.Length + userNameByte.Length];
                byte[] fileNameLen = BitConverter.GetBytes(fileNameByte.Length);
                fileNameLen.CopyTo(downloadUserNameByte, 0);
                fileNameByte.CopyTo(downloadUserNameByte, 4);
                userNameByte.CopyTo(downloadUserNameByte, 4 + fileNameByte.Length);
                clientSocket.Send(functionByte);
                clientSocket.Send(downloadUserNameByte);
            }
        }

        private string findFileName(string oldName)
        { // this function is for appropriately naming the file that user downloaded
            // it takes the name of the file user wants to download and outputs the correct new name
            string[] files = Directory.GetFiles(@fbd.SelectedPath);
            string fName;
            int count = 1;
            // loop is for checking every file that exists in download location and 
            // find the new correct name by counting the file which has the same name as new one
            for (int i = 0; i < files.Length; i++)
            {
                int num = 0;
                fName = files[i];
                fName = fName.Substring(fName.LastIndexOf('\\') + 1);
                if (fName.Contains("_") && fName.Contains(".txt") && Int32.TryParse(fName.Substring(fName.LastIndexOf('_') + 1, fName.IndexOf(".txt") - fName.LastIndexOf('_') - 1), out num)) {
                    string trimmedFileName = fName.Substring(0, fName.LastIndexOf('_'));
                    if (oldName == trimmedFileName)
                    {
                        if (num + 1 > count)
                            count = num + 1;
                    }
                }
            }
            // given the file name fileName_number, it outputs fileName_number_count where count is
            // appropriate number to save the file
            return oldName + "_" + count;
        }

        private void downloadFile()
        {
            // first receive the size of the data, then get the data in chunks
            byte[] sizeBytes = new byte[BUFFER_SIZE];
            int dataLen = clientSocket.Receive(sizeBytes); // receive size of the file
            //int x = BitConverter.ToInt32(sizeBytes, 0);

            if (dataLen == 0) // the client socket is disconnected
                throw new ObjectDisposedException(textBox_username.Text);

            int bytesLeftToReceive = BitConverter.ToInt32(sizeBytes, 0); // byte[] to int conversion
            byte[] fileData = new byte[BUFFER_SIZE];

            string newFileName = findFileName(downloadLocation);

            // if with .txt, update this
            BinaryWriter bWrite = new BinaryWriter(File.Open(@fbd.SelectedPath + "\\" + newFileName + ".txt", FileMode.Append));

            byte[] start = { 200 };
            clientSocket.Send(start);

            // same mechanism as it's applied in server side
            while (bytesLeftToReceive > 0)
            {
                int bytesRead = clientSocket.Receive(fileData, BUFFER_SIZE, 0);
                bWrite.Write(fileData, 0, bytesRead);
                bytesLeftToReceive -= bytesRead;
            }

            bWrite.Close();
            logs.AppendText("File is successfully downloaded.\n");
        }

        private void button_delete_Click(object sender, EventArgs e)
        { // invoked when user wants to delete a file from server
            if (!textBox_delete.Text.Equals(""))
            { // if a filename is provided
                closeButtons();
                byte[] reqArray = { 4 };
                byte[] fileToBeDeleted = new byte[BUFFER_SIZE];
                fileToBeDeleted = Encoding.UTF8.GetBytes(textBox_delete.Text);
                clientSocket.Send(reqArray); // send the correct request code
                clientSocket.Send(fileToBeDeleted); // send the file name to be deleted
            }
            else
            {
                logs.AppendText("You must provide a file name.\n");
            }
        }

        private void button_request_Click(object sender, EventArgs e)
        { // invoked when user requests his/her file list
            closeButtons();
            byte[] reqArray = { 7 };
            clientSocket.Send(reqArray); // send the correct request code
        }

        private void button_public_Click(object sender, EventArgs e)
        { // invoked when user wants to make a file public in server side
            if (!textBox_public.Text.Equals(""))
            { // if a filename is provided
                closeButtons();
                byte[] reqArray = { 8 };
                byte[] fileToBePublic = new byte[BUFFER_SIZE];
                fileToBePublic = Encoding.UTF8.GetBytes(textBox_public.Text);
                clientSocket.Send(reqArray); // send the correct request code
                clientSocket.Send(fileToBePublic); // send the file name
            }
            else
            {
                logs.AppendText("You must provide a file name.\n");
            }
        }

        private void button_public_req_Click(object sender, EventArgs e)
        { // invoked when user requests public files from the server side
            closeButtons();
            byte[] reqArray = { 9 };
            clientSocket.Send(reqArray); // send the correct request code
        }

        private void button_private_download_Click(object sender, EventArgs e)
        { // invoked when user wants to download a PRIVATE FILE from the server
            downloadLocation = textBox_private_filename.Text;
            if (downloadLocation == "")
            {
                logs.AppendText("You must enter a file name to send a download request.\n");
            }
            else
            { // if a file name is provided
                closeButtons();
                byte[] functionByte = { 10 };
                byte[] fileNameByte = Encoding.UTF8.GetBytes(downloadLocation);
                clientSocket.Send(functionByte); // send the correct request code
                clientSocket.Send(fileNameByte); // send the file name to be downloaded
            }
        }
    }
}
